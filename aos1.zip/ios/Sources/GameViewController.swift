import UIKit
import WebKit

class GameViewController: UIViewController, WKURLSchemeHandler, WKNavigationDelegate {
    var web: WKWebView!
    var cover = UIView()
    var tries = 0

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { return .landscape }
    override var prefersStatusBarHidden: Bool { return true }
    override var prefersHomeIndicatorAutoHidden: Bool { return true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { return .all }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(self, forURLScheme: "app")
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        web = WKWebView(frame: view.bounds, configuration: cfg)
        web.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.backgroundColor = .black
        web.scrollView.bounces = false
        web.scrollView.isScrollEnabled = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.navigationDelegate = self
        view.addSubview(web)

        cover.frame = view.bounds
        cover.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        cover.backgroundColor = .black
        let logo = UIImageView(image: UIImage(named: "Logo"))
        logo.contentMode = .scaleAspectFit
        logo.frame = CGRect(x: 0, y: 0, width: 128, height: 128)
        logo.center = CGPoint(x: cover.bounds.midX, y: cover.bounds.midY)
        logo.autoresizingMask = [.flexibleTopMargin, .flexibleBottomMargin, .flexibleLeftMargin, .flexibleRightMargin]
        cover.addSubview(logo)
        view.addSubview(cover)

        web.load(URLRequest(url: URL(string: "app://game/index.html")!))
        waitReady()
    }

    func waitReady() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            guard let self = self else { return }
            self.web.evaluateJavaScript("window.__ready===true") { result, _ in
                self.tries += 1
                if (result as? Bool) == true || self.tries > 400 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                        UIView.animate(withDuration: 0.25, animations: { self.cover.alpha = 0 }) { _ in self.cover.removeFromSuperview() }
                    }
                } else {
                    self.waitReady()
                }
            }
        }
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = Bundle.main.url(forResource: "game", withExtension: "html"),
              let data = try? Data(contentsOf: url, options: .mappedIfSafe) else {
            urlSchemeTask.didFailWithError(NSError(domain: "app", code: 404, userInfo: nil))
            return
        }
        let resp = URLResponse(url: urlSchemeTask.request.url!, mimeType: "text/html", expectedContentLength: data.count, textEncodingName: "utf-8")
        urlSchemeTask.didReceive(resp)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        web.reload()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let u = navigationAction.request.url, u.scheme == "http" || u.scheme == "https" {
            UIApplication.shared.open(u)
            decisionHandler(.cancel)
        } else {
            decisionHandler(.allow)
        }
    }
}
