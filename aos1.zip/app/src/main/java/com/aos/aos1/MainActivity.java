package com.aos.aos1;
import android.app.Activity; import android.content.Intent; import android.graphics.Color; import android.net.Uri; import android.os.Build; import android.os.Bundle; import android.os.Handler;
import android.view.*; import android.webkit.*; import android.widget.Toast; import java.util.Collections;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    WebView w; long lastBack = 0;
    @Override protected void onCreate(Bundle b) {
        setTheme(android.R.style.Theme_Material_NoActionBar_Fullscreen);
        super.onCreate(b);
        Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) win.getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        win.setBackgroundDrawableResource(R.drawable.splash);
        w = new WebView(this); w.setBackgroundColor(Color.BLACK); setContentView(w);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setLoadWithOverviewMode(false);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER); w.setVerticalScrollBarEnabled(false); w.setHorizontalScrollBarEnabled(false);
        w.setLongClickable(false); w.setHapticFeedbackEnabled(false); w.setOnLongClickListener(v -> true);
        w.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return loader.shouldInterceptRequest(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (r.getUrl().getHost() != null && r.getUrl().getHost().equals("appassets.androidplatform.net")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) { recreate(); return true; }
        });
        w.loadUrl("https://appassets.androidplatform.net/assets/game.html");
        immersive();
    }
    void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
    @Override public void onAttachedToWindow() { super.onAttachedToWindow(); }
    @Override protected void onPause() { super.onPause(); w.onPause(); w.pauseTimers(); }
    @Override protected void onResume() { super.onResume(); w.onResume(); w.resumeTimers(); immersive(); }
    @Override protected void onDestroy() { if (w != null) { w.destroy(); } super.onDestroy(); }
    @Override public void onBackPressed() {
        long t = System.currentTimeMillis();
        if (t - lastBack < 1800) { finish(); return; }
        lastBack = t;
        w.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))", null);
        Toast.makeText(this, "\u518d\u6309\u4e00\u6b21\u8fd4\u56de\u9375\u96e2\u958b", Toast.LENGTH_SHORT).show();
    }
    @Override public void onWindowAttributesChanged(WindowManager.LayoutParams p) { super.onWindowAttributesChanged(p); }
    @Override public void onContentChanged() { super.onContentChanged(); if (Build.VERSION.SDK_INT >= 29) { final View c = findViewById(android.R.id.content); c.addOnLayoutChangeListener((v, l, tp, r, bt, a, b2, c2, d) -> v.setSystemGestureExclusionRects(Collections.singletonList(new android.graphics.Rect(0, 0, r - l, bt - tp)))); } }
}
