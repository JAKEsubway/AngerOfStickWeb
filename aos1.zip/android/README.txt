Build: open this folder in Android Studio (Build > Build APK), or run `gradle assembleRelease`
(needs Android SDK 34 + JDK 17), or push to GitHub and download the apk artifact from Actions.
